///////////////////////////////////////////////////////////////////////////////
//              TCP Ŭ���̾�Ʈ ���α׷�
//
//              ���� ���� �ܼ�
//
// ������:
// ���α׷���:
///////////////////////////////////////////////////////////////////////////////

#pragma warning(disable:4996)   //���ȿ� ����ϴٴ� �ܼҸ��� ����
#define  WIN32_LEAN_AND_MEAN
#undef UNICODE
#include <windows.h>
#include <winsock2.h>
#include <stdio.h>

#define LOCAL(Type) static Type WINAPI
#define Printf printf


#define SERVERIP            "127.0.0.1"
#define SERVERPORT          80
#define DEFAULTHTTPPORTNO   80



//-----------------------------------------------------------------------------
//      ���� ���� �ݴϴ�
//-----------------------------------------------------------------------------
int WINAPI GetMin(int A, int B) {return A<=B ? A:B;}



//������ �ʱ�ȭ
BOOL WINAPI SocketInit(WSADATA*lpWSAD)
    {
    BOOL Rslt=FALSE;
    WSADATA WSAD;

    if (lpWSAD==NULL) lpWSAD=&WSAD;
    if (WSAStartup(MAKEWORD(2, 2), lpWSAD)!=0) goto DispErr;
    if (lpWSAD->wVersion!=0x0202)                                               //WS_32.DLL �����˻�
        {
        WSACleanup();

        DispErr:
        printf("���϶��̺귯���� �ʱ�ȭ �� �� �����ϴ�.");
        goto ProcExit;
        }
    Rslt++;

    ProcExit:
    return Rslt;
    }




//���� ���ڿ��� 0x�� �����ϴ� Hex���ڿ��� ��ġ�� ��ȭ��
//NonStrLoc���� ��ġ�� �ƴ� ���ڿ��� ��ġ��
int WINAPI AtoI(LPCSTR Str, int*NonStrLoc=NULL);
int WINAPI AtoI(LPCSTR Str, int*NonStrLoc)
    {
    int Rslt, Sign, HexMode, NoErr;
    char Cha, Cha2;
    LPCSTR lp;

    Rslt=Sign=HexMode=NoErr=0;
    lp=Str;
    for (;;)
        {
        Cha=*lp++;
        if (Cha>0 && Cha<=' ') continue;
        if (Cha=='+') break;
        if (Cha=='-') {Sign++; break;}
        if (Cha=='0')
            {
            Cha2=*lp++;
            if (Cha2=='x' || Cha2=='X') HexMode++; else lp-=2;
            }
        else lp--;
        break;
        }

    for (;;)
        {
        Cha=*lp++;
        if (Cha<'0') break;
        if (Cha<='9') {Cha-='0'; goto AddDigit;}
        if (HexMode==0) break;
        if (Cha<'A') break;
        if (Cha<='F') {Cha-='A'-10; goto AddDigit;}
        if (Cha<'a' || Cha>'f') break;
        Cha-='a'-10;

        AddDigit:
        NoErr=1;
        if (HexMode) Rslt<<=4;
        else{
            Rslt<<=1;
            Rslt+=Rslt<<2;                                                      //*10
            }
        Rslt+=Cha;
        }

    if (NonStrLoc)*NonStrLoc=(NoErr)?(int)(lp-Str)-1:0;
    if (Sign) Rslt=-Rslt;
    return Rslt;
    }




//  IP ���ڿ���WORD IP�� ��ȯ�� �ݴϴ�
DWORD WINAPI AtoIP(LPCSTR IPStr)
    {
    int I, J;
    UINT K;
    DWORD IP=0;
    LPCSTR lp;

    lp=IPStr;
    for (I=0;; I++)
        {
        K=AtoI(lp, &J);
        if (J==0 || K>255)
            {
            Err:
            IP=0;
            break;
            }
        IP>>=8;
        IP|=K<<24;
        lp+=J;
        if (I==3)
            {
            if (lp[0]!=0) goto Err;
            break;
            }
        else{
            if (lp[0]!='.') goto Err;
            lp++;
            }
        }
    return IP;
    }



//------------------------------------------------------------------------------
//      ���ڿ��� �и��մϴ� (�и����� ������ ���ڿ��� ��)
//------------------------------------------------------------------------------
LPSTR WINAPI SeparatStr(LPSTR Str, CHAR SepCha)
    {
    LPSTR lp;

    if ((lp=strchr(Str, SepCha))!=NULL)
        {
        lp[0]=0;
        lp++;
        }
    return lp;
    }



//-----------------------------------------------------------------------------
//              ������ ��ŵ�մϴ�
//-----------------------------------------------------------------------------
LPCSTR WINAPI SkipSpace(LPCSTR Str)
    {
    BYTE Cha;

    for (;;)
        {
        Cha=*Str++;
        if (Cha==0 || Cha>' ') break;
        }
    return Str-1;
    }



//-----------------------------------------------------------------------------
//      ���� ��ġ �ܾ ���� �ݴϴ� (�����̳� TAB����) (sscanf()�� %s���)
//      ���� �ܾ��� ������ġ�� ������
//      '�� "�� ���ΰ�� �� ���̸� ��� ���� �ݴϴ�
//-----------------------------------------------------------------------------
LPCSTR WINAPI ScanWord(LPCSTR Str, LPSTR Buff, int BuffLen)
    {
    int Cha, FirstCha, Dest=0;

    Str=SkipSpace(Str);
    FirstCha=Str[0];
    if (FirstCha==0x27 || FirstCha==0x22) Str++;     //"'", '"'
    else FirstCha=0;

    for (;;)
        {
        Cha=*(BYTE*)Str++;
        if (Cha==0) {Str--; break;}
        if (FirstCha!=0)
            {
            if (FirstCha==Cha) break;
            }
        else{
            if (Cha<=' ') break;
            }
        if (Dest+1<BuffLen) Buff[Dest++]=Cha;
        }

    if (Dest<BuffLen) Buff[Dest]=0;
    return SkipSpace(Str);
    }



//------------------------------------------------------------------------------
//      FullPath���� ���ϸ��� ��ġ�� �����մϴ�
//------------------------------------------------------------------------------
LOCAL(LPCSTR) GetFileNameLoc(LPCSTR FullPath)
    {
    LPCSTR lp;

    if ((lp=strrchr(FullPath, '/'))==NULL) lp=FullPath;
    else lp++;

    return lp;
    }



LOCAL(int) CompMemStr(LPCSTR Mem, LPCSTR Str)
    {
    return memcmp(Mem, Str, lstrlen(Str));
    }



//-----------------------------------------------------------------------------
//      ������ ������ŷ���� ��ȯ�մϴ�
//-----------------------------------------------------------------------------
int WINAPI SetNonBlockingMode(SOCKET hSocket, BOOL NonBlockingFg)
    {
    return ioctlsocket(hSocket, FIONBIO, (DWORD*)&NonBlockingFg);
    }



//-----------------------------------------------------------------------------
//          �־��� Byte�� ��� �����մϴ�
//-----------------------------------------------------------------------------
LOCAL(BOOL) SendAll(SOCKET hSocket, LPCSTR Data, int DataSize)
    {
    int  Sended, Err;
    BOOL Rslt=FALSE;

    while (DataSize>0)
        {
        if ((Sended=send(hSocket, Data, DataSize, 0))<=0)
            {
            if ((Err=WSAGetLastError())==WSAEWOULDBLOCK)
                {
                Sleep(1);
                continue;
                }
            printf("send() error=%d\n", Err);
            goto ProcExit;
            }
        DataSize-=Sended;
        Data+=Sended;
        }
    Rslt=TRUE;

    ProcExit:
    return Rslt;
    }


//���ڿ� ����
int WINAPI SendStr(SOCKET hSocket, LPCSTR Data)
    {
    return SendAll(hSocket, Data, lstrlen(Data));
    }




//Port�� ������ (IP�� ���ε��, ��Ʈ�� ��Ʋ�ε��)
int WINAPI MyConnect(SOCKET hSocket, LPCSTR IP, WORD PortNo)
    {
    SOCKADDR_IN SA;

    ZeroMemory(&SA, sizeof(SOCKADDR_IN));
    SA.sin_family=AF_INET;
    SA.sin_port=htons(PortNo);
    SA.sin_addr.s_addr=AtoIP(SERVERIP);
    return connect(hSocket, (SOCKADDR*)&SA, sizeof(SA));
    }



BOOL WINAPI RecvLine(SOCKET hSocket, LPSTR Buff, int BuffSize, DWORD Timeout)
    {
    BOOL Rslt=FALSE;
    CHAR Cha;
    DWORD Time;

    Time=GetTickCount();
    for (;;)
        {
        if (recv(hSocket, &Cha, 1, 0)<=0)
            {
            if (WSAGetLastError()!=WSAEWOULDBLOCK) break;
            if (GetTickCount()-Time>=Timeout) break;
            Sleep(1);
            continue;
            }
        if (Cha=='\r') continue;
        if (Cha=='\n') {Rslt=TRUE; break;}
        if (BuffSize>1) {*Buff++=Cha; BuffSize--;}
        }

    if (BuffSize>0)*Buff=0;
    return Rslt;
    }




//-----------------------------------------------------------------------------
//      '+'�� %2B �������� �ٲߴϴ�
//-----------------------------------------------------------------------------
LPSTR WINAPI ChaToWebCode(LPSTR Buff, char Cha)
    {
    BYTE B;

    *Buff++='%';
    if ((B=((BYTE)Cha>>4)+'0')>'9') B+=7;
    *Buff++=B;
    if ((B=((BYTE)Cha & 0x0F)+'0')>'9') B+=7;
    *Buff++=B;
    return Buff;
    }



//------------------------------------------------------------------------------
//      ������ �浹�Ǵ� ���ڿ��� �ڵ�� �ٲߴϴ�
//      �ٸ� �̸� EncodePsntHexStrII()
//      Sub����22=&11 -> Sub%C1%A6%B8%F122%3D%2611
//------------------------------------------------------------------------------
int WINAPI EncodeUrl(LPSTR Buff, LPCSTR Url, int BuffSize)
    {
    int  TotalChars=0;
    BYTE B;
    LPSTR lp;

    lp=Buff;
    while ((B=*Url++)!=0)
        {
        if (B<=' ' ||
            B=='+' ||
            B=='?' ||
            B=='&' ||
            B=='#' ||
            B=='%' ||
            B==0x5C)    //'\'
            {
            if (BuffSize<=3) break;
            if (Buff!=NULL) lp=ChaToWebCode(lp, B);
            BuffSize-=3;
            TotalChars+=3;
            }
        else{
            if (BuffSize<=1) break;
            if (Buff!=NULL) *lp++=B;
            BuffSize--;
            TotalChars++;
            }
        }
    *lp=0;
    return TotalChars;
    }




//-----------------------------------------------------------------------------
//      Http Client
//      RecvBuffSize==0 �� ��쿡�� RecvBuff �� ���ϸ����� �ؼ� ���Ͽ� ������
//
//      ServerDomain�� �� http://Server:1234/File.html?User=MY
//
//��û���
//      GET /FileManager?Cmd=FileList&Path=C:/User HTTP/1.0
//      Host: www.ojang.pe.kr
//      User-Agent: FileDownloadProgram/1.00
//      Accept: */*
//
//�������
//      HTTP/1.1 200 OK
//      Date: Tue, 10 Jul 2018 14:32:02 GMT
//      Server: Apache/1.3.34 (Win32) PHP/4.4.2
//      Last-Modified: Wed, 05 Jul 2017 14:30:12 GMT    //������������ð�
//      Accept-Ranges: bytes
//      Content-Length: 59660947                        //����ũ��
//      Connection: close
//      Content-Type: application/zip
//      <����> ... ��� ��
//      ���ϸ�ü
//-----------------------------------------------------------------------------
LOCAL(int) HttpClient(LPCSTR Url, LPSTR RecvBuff, int RecvBuffSize)
    {
    int Len, Port=DEFAULTHTTPPORTNO, RecvBytes, TotalRecvBytes=0, HttpRslt=0;
    HFILE hFile=HFILE_ERROR;
    SOCKET hSocket=INVALID_SOCKET;
    LPCSTR lp, SvrPath;
    CHAR Buff[MAX_PATH*3], Temp[40], ServerDomain[64];

    //Url -> http://Server:1234/File.html?User=MY
    //ó������ ServerDomain<-'Server', Port<-1234, SvrPath<-'/File.html?User=MY'
    if ((lp=strstr(Url, "://"))!=NULL) lp+=3; else lp=Url;  //3:Len("://")
    SvrPath=strchr(lp, '/');
    Len=SvrPath ? SvrPath-lp:lstrlen(lp);
    lstrcpyn(ServerDomain, lp, GetMin(Len+1, sizeof(ServerDomain)));
    if ((lp=SeparatStr(ServerDomain, ':'))!=NULL) Port=AtoI(lp, NULL);

    if ((hSocket=socket(AF_INET, SOCK_STREAM, 0))==INVALID_SOCKET)
        {
        printf("socket(): %d\n", WSAGetLastError());
        goto ProcExit;
        }

    if (MyConnect(hSocket, ServerDomain, Port)==SOCKET_ERROR)
        {
        printf("Connet Connect %s:%d\n", ServerDomain, Port);
        goto ProcExit;
        }

    //��û ��� �۽�
    wsprintf(Buff, "GET %s HTTP/1.0\r\n"
                   "User-Agent: NULL\r\n"
                   "Accept: */*\r\n"
                   "\r\n", SvrPath ? SvrPath:"/");

    SendStr(hSocket, Buff);

    SetNonBlockingMode(hSocket, TRUE);

    //Http ���� ��� ����
    if (RecvLine(hSocket, Buff, sizeof(Buff), 5000)==FALSE) goto ProcExit;
    lp=ScanWord(Buff, Temp, sizeof(Temp));
    if (CompMemStr(Temp, "HTTP/")!=0)
        {
        printf("No http server\n");
        goto ProcExit;
        }
    if ((HttpRslt=AtoI(lp))!=200)
        {
        printf("http Result=%d\n", HttpRslt);
        goto ProcExit;
        }

    for (;;)
        {
        if (RecvLine(hSocket, Buff, sizeof(Buff), 5000)==FALSE) goto ProcExit;
        if (Buff[0]==0) break;  //��� ��
        }

    //���⼭���ʹ� ��ü�� ����
    if (RecvBuffSize>0)
        {       //�޸𸮿� �ٿ�ε�
        while (RecvBuffSize>0)
            {
            if ((RecvBytes=recv(hSocket, RecvBuff, RecvBuffSize, 0))<=0)
                {
                if (WSAGetLastError()!=WSAEWOULDBLOCK) break;
                Sleep(1);
                continue;
                }

            RecvBuff+=RecvBytes;
            RecvBuffSize-=RecvBytes;
            TotalRecvBytes+=RecvBytes;
            }
        }
    else{       //���Ͽ� �ٿ�ε�
        if ((hFile=_lcreat(RecvBuff, 0))==HFILE_ERROR)
            {
            printf("'%s' cannot Create\n", RecvBuff);
            goto ProcExit;
            }

        for (;;)
            {
            if ((RecvBytes=recv(hSocket, Buff, sizeof(Buff), 0))<=0)
                {
                if (WSAGetLastError()!=WSAEWOULDBLOCK) break;
                Sleep(1);
                continue;
                }
             if (_lwrite(hFile, Buff, RecvBytes)!=RecvBytes)
                {
                printf("Disk Full\n");
                goto ProcExit;
                }
            TotalRecvBytes+=RecvBytes;
            }
        }

    ProcExit:
    if (hFile!=HFILE_ERROR) _lclose(hFile);
    if (hSocket!=INVALID_SOCKET) closesocket(hSocket);
    return TotalRecvBytes;
    }

LOCAL(int) HttpClient(LPCSTR Url, LPCSTR FileName)
    {
    return HttpClient(Url, (LPSTR)FileName, 0);
    }



//-----------------------------------------------------------------------------
//      ������ ���ε��ϴ� Http Ŭ���̾�Ʈ
//-----------------------------------------------------------------------------
LOCAL(int) HttpClientUpload(LPCSTR Url, LPSTR RecvBuff, int RecvBuffSize, LPCSTR ToUploadFName)
    {
    int Len, Port=DEFAULTHTTPPORTNO, RecvBytes, TotalRecvBytes=0, HttpRslt=0;
    HFILE hFile=HFILE_ERROR;
    SOCKET hSocket=INVALID_SOCKET;
    LPCSTR lp, SvrPath;
    CHAR Buff[MAX_PATH*3], Temp[40], ServerDomain[64];

    //Url -> http://Server:1234/File.html?User=MY
    //ó������ ServerDomain<-'Server', Port<-1234, SvrPath<-'/File.html?User=MY'
    if ((lp=strstr(Url, "://"))!=NULL) lp+=3; else lp=Url;  //3:Len("://")
    SvrPath=strchr(lp, '/');
    Len=SvrPath ? SvrPath-lp:lstrlen(lp);
    lstrcpyn(ServerDomain, lp, GetMin(Len+1, sizeof(ServerDomain)));
    if ((lp=SeparatStr(ServerDomain, ':'))!=NULL) Port=AtoI(lp, NULL);

    if ((hSocket=socket(AF_INET, SOCK_STREAM, 0))==INVALID_SOCKET)
        {
        printf("socket(): %d\n", WSAGetLastError());
        goto ProcExit;
        }

    if (MyConnect(hSocket, ServerDomain, Port)==SOCKET_ERROR)
        {
        printf("Connet Connect %s:%d\n", ServerDomain, Port);
        goto ProcExit;
        }

    //��û ��� �۽�
    wsprintf(Buff, "GET %s HTTP/1.0\r\n"
                   "User-Agent: NULL\r\n"
                   "Accept: */*\r\n"
                   "\r\n", SvrPath ? SvrPath:"/");

    SendStr(hSocket, Buff);

    SetNonBlockingMode(hSocket, TRUE);

    //���� �ٵ� ����
    if ((hFile=_lopen(ToUploadFName, OF_READ))==HFILE_ERROR)
        {
        printf("'%s' cannot read\n", ToUploadFName);
        goto ProcExit;
        }

    for (;;)
        {
        int ReadBytes;

        if ((ReadBytes=_lread(hFile, Buff, sizeof(Buff)))==0) break;
        if (ReadBytes==HFILE_ERROR) break;
        if (SendAll(hSocket, Buff, ReadBytes)==FALSE)
            {
            printf("Disconnected for upload\n");
            break;
            }
        }

    //Http ���� ��� ����
    if (RecvLine(hSocket, Buff, sizeof(Buff), 5000)==FALSE) goto ProcExit;
    lp=ScanWord(Buff, Temp, sizeof(Temp));
    if (CompMemStr(Temp, "HTTP/")!=0)
        {
        printf("No http server\n");
        goto ProcExit;
        }
    if ((HttpRslt=AtoI(lp))!=200)
        {
        printf("http Result=%d\n", HttpRslt);
        goto ProcExit;
        }

    for (;;)
        {
        if (RecvLine(hSocket, Buff, sizeof(Buff), 5000)==FALSE) goto ProcExit;
        if (Buff[0]==0) break;  //��� ��
        }

    //���⼭���ʹ� ��ü�� ����
    while (RecvBuffSize>0)
        {
        if ((RecvBytes=recv(hSocket, RecvBuff, RecvBuffSize, 0))<=0)
            {
            if (WSAGetLastError()!=WSAEWOULDBLOCK) break;
            Sleep(1);
            continue;
            }

        RecvBuff+=RecvBytes;
        RecvBuffSize-=RecvBytes;
        TotalRecvBytes+=RecvBytes;
        }

    ProcExit:
    if (hFile!=HFILE_ERROR) _lclose(hFile);
    if (hSocket!=INVALID_SOCKET) closesocket(hSocket);
    return TotalRecvBytes;
    }



//-----------------------------------------------------------------------------
//      �������� ���� ����� ������
//-----------------------------------------------------------------------------
LOCAL(VOID) DirProc(LPCSTR Param)
    {
    int RecvBytes;
    CHAR Url[MAX_PATH*2], RecvBuff[1024];

    if (Param==NULL)
        {
        printf("Dir �н�\n");
        goto ProcExit;
        }

    EncodeUrl(RecvBuff, Param, sizeof(RecvBuff));
    wsprintf(Url, "http://%s:%d/FileManager?Cmd=FileList&Path=%s", SERVERIP, SERVERPORT, RecvBuff);
    if ((RecvBytes=HttpClient(Url, RecvBuff, sizeof(RecvBuff)-1))==0)
        {
        printf("Dir Error\n");
        goto ProcExit;
        }
    RecvBuff[RecvBytes]=0;

    printf(RecvBuff);

    ProcExit:;
    }



//-----------------------------------------------------------------------------
//      �������� ������ ������
//-----------------------------------------------------------------------------
LOCAL(VOID) DelProc(LPCSTR Param)
    {
    int RecvBytes;
    CHAR Url[MAX_PATH*2], RecvBuff[1024];

    if (Param==NULL)
        {
        printf("Del ���������ϸ�\n");
        goto ProcExit;
        }

    EncodeUrl(RecvBuff, Param, sizeof(RecvBuff));
    wsprintf(Url, "http://%s:%d/FileManager?Cmd=DeleteFile&Path=%s", SERVERIP, SERVERPORT, RecvBuff);
    if ((RecvBytes=HttpClient(Url, RecvBuff, sizeof(RecvBuff)-1))==0)
        {
        printf("Dir Error\n");
        goto ProcExit;
        }
    RecvBuff[RecvBytes]=0;

    printf(RecvBuff);

    ProcExit:;
    }



//-----------------------------------------------------------------------------
//      �������� ������ �ٿ�ε���
//-----------------------------------------------------------------------------
LOCAL(VOID) DownlaodProc(LPCSTR Param)
    {
    int RecvBytes;
    CHAR Url[MAX_PATH*2], EncBuff[MAX_PATH*2];

    if (Param==NULL)
        {
        printf("Download �ٿ�������ϸ�\n");
        goto ProcExit;
        }

    EncodeUrl(EncBuff, Param, sizeof(EncBuff));
    wsprintf(Url, "http://%s:%d/FileManager?Cmd=Download&Path=%s", SERVERIP, SERVERPORT, EncBuff);
    //wsprintf(Url, "http://%s:%d/%s", SERVERIP, SERVERPORT, Param);
    if ((RecvBytes=HttpClient(Url, GetFileNameLoc(Param)))==0)
        {
        printf("Download Error\n");
        goto ProcExit;
        }
    printf("%d Bytes Download OK\n", RecvBytes);

    ProcExit:;
    }



//-----------------------------------------------------------------------------
//      �������� ������ �����Ŀ� ���ε���
//-----------------------------------------------------------------------------
LOCAL(VOID) UploadProc(LPCSTR Param)
    {
    int RecvBytes;
    LPCSTR lp;
    CHAR Url[MAX_PATH*2], LocalPath[MAX_PATH], SvrPath[MAX_PATH], EncSvrPath[MAX_PATH*2];
    CHAR RecvBuff[MAX_PATH];

    if (Param==NULL)
        {
        printf("Upload �������ϸ� �������ϸ�\n");
        goto ProcExit;
        }

    lp=ScanWord(Param, LocalPath, sizeof(LocalPath));
    ScanWord(lp, SvrPath, sizeof(SvrPath));

    EncodeUrl(EncSvrPath, SvrPath, sizeof(SvrPath));
    wsprintf(Url, "http://%s:%d/FileManager?Cmd=Upload&Path=%s", SERVERIP, SERVERPORT, EncSvrPath);
    //wsprintf(Url, "http://%s:%d/%s", SERVERIP, SERVERPORT, Param);

    if ((RecvBytes=HttpClientUpload(Url, RecvBuff, sizeof(RecvBuff)-1, LocalPath))==0)
        {
        printf("Upload Error\n");
        goto ProcExit;
        }
    RecvBuff[RecvBytes]=0;
    printf("Upload '%s'\n", RecvBuff);

    ProcExit:;
    }



//�ָܼ���
int main()
    {
    LPCSTR Param;
    CHAR Buff[256];

    printf("Remote Computer File Console Program Ver 1.00\n");

    SocketInit(NULL);

    for (;;)
        {
        gets_s(Buff);
        Param=SeparatStr(Buff, ' ');

        if (lstrcmpi(Buff, "Quit")==0 ||
            lstrcmpi(Buff, "Exit")==0)
            {
            printf("Exit Program\n");
            break;
            }
        else if (lstrcmpi(Buff, "Dir")==0)      DirProc(Param);
        else if (lstrcmpi(Buff, "Del")==0)      DelProc(Param);
        else if (lstrcmpi(Buff, "Download")==0) DownlaodProc(Param);
        else if (lstrcmpi(Buff, "Upload")==0)   UploadProc(Param);
        else{
            printf("Not Support yet\n");
            }
        }

    WSACleanup();
    return 0;
    }

