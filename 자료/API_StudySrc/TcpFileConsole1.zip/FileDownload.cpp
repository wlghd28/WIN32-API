///////////////////////////////////////////////////////////////////////////////
//              TCP ���ϴٿ�ε�
//
//  http://www.ojang.pe.kr/VC15.zip
//
// ������:
// ���α׷���:
///////////////////////////////////////////////////////////////////////////////

#pragma warning(disable:4996)   //���ȿ� ����ϴٴ� �ܼҸ��� ����
#define  WIN32_LEAN_AND_MEAN
#undef UNICODE
#include <windows.h>
#include <winsock2.h>
#include <stdio.h>


#define SERVERIP        "127.0.0.1"
#define PORTNO          80



//-----------------------------------------------------------------------------
//      ������ �ʱ�ȭ
//-----------------------------------------------------------------------------
BOOL WINAPI SocketInit(WSADATA *lpWSAD)
    {
    BOOL Rslt=FALSE;
    WSADATA WSAD;

    if (lpWSAD==NULL) lpWSAD=&WSAD;
    if (WSAStartup(MAKEWORD(2, 2), lpWSAD)!=0) goto DispErr;
    if (lpWSAD->wVersion!=0x0202)       //WS_32.DLL �����˻�
        {
        WSACleanup();

        DispErr:
        printf("���϶��̺귯���� �ʱ�ȭ �� �� �����ϴ�.");
        goto ProcExit;
        }
    Rslt++;

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      ������ �̸��� IP�� �ٲߴϴ�
//      DomainName ���� ���� ��ǻ�� �̸��� �־ ��
//      Fail�ΰ�� INADDR_NONE(-1)�� ������
//-----------------------------------------------------------------------------
DWORD WINAPI DomainNameToIP(LPCSTR DomainName)
    {
    DWORD IP;
    HOSTENT *HE;

    if ((IP=inet_addr(DomainName))==INADDR_NONE)
        {
        if (IP==INADDR_NONE && (HE=gethostbyname(DomainName))!=NULL)
            IP=((IN_ADDR*)HE->h_addr)->s_addr;
        }
    return IP;
    }



//-----------------------------------------------------------------------------
//      Port�� ������ (IP�� ���ε��, ��Ʈ�� ��Ʋ�ε��)
//-----------------------------------------------------------------------------
int WINAPI MyConnect(SOCKET hSocket, LPCSTR Domain, WORD PortNo)
    {
    SOCKADDR_IN SA;

    ZeroMemory(&SA, sizeof(SOCKADDR_IN));
    SA.sin_family=AF_INET;
    SA.sin_port=htons(PortNo);
    SA.sin_addr.s_addr=DomainNameToIP(Domain);
    return connect(hSocket, (SOCKADDR*)&SA, sizeof(SA));
    }



//-----------------------------------------------------------------------------
//      ������ ������ŷ���� ��ȯ�մϴ�
//-----------------------------------------------------------------------------
int WINAPI SetNonBlockingMode(SOCKET hSocket, BOOL NonBlockingFg)
    {
    return ioctlsocket(hSocket, FIONBIO, (DWORD*)&NonBlockingFg);
    }



//-----------------------------------------------------------------------------
//      ���ڿ��� �����մϴ�
//-----------------------------------------------------------------------------
int WINAPI SendStr(SOCKET hSocket, LPCSTR Data)
    {
    return send(hSocket, Data, lstrlen(Data), 0);
    }



//-----------------------------------------------------------------------------
//      ������ �д´�
//-----------------------------------------------------------------------------
BOOL WINAPI RecvLine(SOCKET hSocket, LPSTR Buff, int BuffSize, DWORD Timeout)
    {
    BOOL Rslt=FALSE;
    CHAR Cha;
    DWORD Time;

    Time=GetTickCount();
    for (;;)
        {
        if (recv(hSocket, &Cha, 1, 0)<=0)
            {
            if (WSAGetLastError()!=WSAEWOULDBLOCK) break;
            if (GetTickCount()-Time>=Timeout) break;
            Sleep(1);
            continue;
            }
        if (Cha=='\r') continue;
        if (Cha=='\n') {Rslt=TRUE; break;}
        if (BuffSize>1) {*Buff++=Cha; BuffSize--;}
        }

    if (BuffSize>0) *Buff=0;
    return Rslt;
    }



//-----------------------------------------------------------------------------
//              ������ ��ŵ�մϴ�
//-----------------------------------------------------------------------------
LPCSTR WINAPI SkipSpace(LPCSTR Str)
    {
    BYTE Cha;

    for (;;)
        {
        Cha=*Str++;
        if (Cha==0 || Cha>' ') break;
        }
    return Str-1;
    }



//-----------------------------------------------------------------------------
//      ���� ��ġ �ܾ ���� �ݴϴ� (�����̳� TAB����) (sscanf()�� %s���)
//      ���� �ܾ��� ������ġ�� ������
//      '�� "�� ���ΰ�� �� ���̸� ��� ���� �ݴϴ�
//-----------------------------------------------------------------------------
LPCSTR WINAPI ScanWord(LPCSTR Str, LPSTR Buff, int BuffLen)
    {
    int Cha, FirstCha, Dest=0;

    Str=SkipSpace(Str);
    FirstCha=Str[0];
    if (FirstCha==0x27 || FirstCha==0x22) Str++;     //"'", '"'
    else FirstCha=0;

    for (;;)
        {
        Cha=*(BYTE*)Str++;
        if (Cha==0) {Str--; break;}
        if (FirstCha!=0)
            {
            if (FirstCha==Cha) break;
            }
        else{
            if (Cha<=' ') break;
            }
        if (Dest+1<BuffLen) Buff[Dest++]=Cha;
        }

    if (Dest<BuffLen) Buff[Dest]=0;
    return SkipSpace(Str);
    }



//-----------------------------------------------------------------------------
//      ���� ���ڿ��� 0x�� �����ϴ� Hex���ڿ��� ��ġ�� ��ȭ��
//      NonStrLoc���� ��ġ�� �ƴ� ���ڿ��� ��ġ��
//-----------------------------------------------------------------------------
int WINAPI AtoI(LPCSTR Str, int *NonStrLoc)
    {
    int  Rslt, Sign, HexMode, NoErr;
    char Cha, Cha2;
    LPCSTR lp;

    Rslt=Sign=HexMode=NoErr=0;
    lp=Str;
    for (;;)
        {
        Cha=*lp++;
        if (Cha>0 && Cha<=' ') continue;
        if (Cha=='+') break;
        if (Cha=='-') {Sign++; break;}
        if (Cha=='0')
            {
            Cha2=*lp++;
            if (Cha2=='x' || Cha2=='X') HexMode++; else lp-=2;
            }
        else lp--;
        break;
        }

    for (;;)
        {
        Cha=*lp++;
        if (Cha<'0') break;
        if (Cha<='9') {Cha-='0'; goto AddDigit;}
        if (HexMode==0) break;
        if (Cha<'A') break;
        if (Cha<='F') {Cha-='A'-10; goto AddDigit;}
        if (Cha<'a' || Cha>'f') break;
        Cha-='a'-10;

        AddDigit:
        NoErr=1;
        if (HexMode) Rslt<<=4;
        else{
            Rslt<<=1;
            Rslt+=Rslt<<2;      //*10
            }
        Rslt+=Cha;
        }

    if (NonStrLoc) *NonStrLoc=(NoErr) ? (int)(lp-Str)-1:0;
    if (Sign) Rslt=-Rslt;
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      �ܼ� ��Ǯ ����
//
//��û���
//      GET /FileManager?Cmd=FileList&Path=C:/User HTTP/1.0
//      Host: www.ojang.pe.kr
//      User-Agent: FileDownloadProgram/1.00
//      Accept: */*
//
//�������
//      HTTP/1.1 200 OK
//      Date: Tue, 10 Jul 2018 14:32:02 GMT
//      Server: Apache/1.3.34 (Win32) PHP/4.4.2
//      Last-Modified: Wed, 05 Jul 2017 14:30:12 GMT    //������������ð�
//      Accept-Ranges: bytes
//      Content-Length: 59660947                        //����ũ��
//      Connection: close
//      Content-Type: application/zip
//      <����> ... ��� ��
//      ���ϸ�ü
//-----------------------------------------------------------------------------
int main()
    {
    int    HttpRslt;
    SOCKET hSocket=INVALID_SOCKET;
    HFILE  hFile=HFILE_ERROR;
    DWORD  TotalRecvBytes=0, Time;
    LPCSTR lp;
    CHAR   Buff[256], OneWord[40];

    printf("Http�������� ������ �ٿ�ε��ϴ� ���α׷�\n");

    SocketInit(NULL);

    if ((hSocket=socket(AF_INET, SOCK_STREAM, 0))==INVALID_SOCKET)
        {
        printf("socket() �Լ� ����: %d\n", WSAGetLastError());
        goto ProcExit;
        }

    if (MyConnect(hSocket, SERVERIP, PORTNO)==SOCKET_ERROR)
        {
        printf("MyConnect(%s, %d) ����: %d\n", SERVERIP, PORTNO, WSAGetLastError());
        goto ProcExit;
        }

    //(1) ��û��� ����
    SendStr(hSocket, "GET /VC15.zip HTTP/1.0\r\n"
                     "Host: www.ojang.pe.kr\r\n"
                     "User-Agent: FileDownloadProgram/1.00\r\n"
                     "Accept: */*\r\n"
                     "\r\n");

    SetNonBlockingMode(hSocket, TRUE);

    //(2) ���� HTTP ����� ù�� �����Ͽ� �м�
    if (RecvLine(hSocket, Buff, sizeof(Buff), 5000)==FALSE)
        {
        printf("Http No Header\n");
        goto ProcExit;
        }

    lp=ScanWord(Buff, OneWord, sizeof(OneWord));
    if (memcmp(OneWord, "HTTP/", 5)!=0)
        {
        printf("Unknown Http Header\n");
        goto ProcExit;
        }

    ScanWord(lp, OneWord, sizeof(OneWord));
    if ((HttpRslt=AtoI(OneWord, NULL))!=200)
        {
        printf("Http error=%d\n", HttpRslt);
        goto ProcExit;
        }

    //(3) ���� HTTP ����� �����Ͽ� �м�
    for (;;)
        {
        if (RecvLine(hSocket, Buff, sizeof(Buff), 5000)==FALSE)
            {
            printf("RecvLine() Error\n");
            goto ProcExit;
            }
        if (Buff[0]==0) break;  //������ ����� ��
        }


    if ((hFile=_lcreat("VC15.zip", 0))==HFILE_ERROR)
        {
        printf("File Create Error\n");
        goto ProcExit;
        }

    //(4) ���� ��ü �����Ͽ� ���Ϸ� ����
    Time=GetTickCount();
    for (;;)
        {
        int RecvBytes;

        if ((RecvBytes=recv(hSocket, Buff, sizeof(Buff), 0))<=0)
            {
            if (WSAGetLastError()!=WSAEWOULDBLOCK)
                {
                printf("Disconnected\n");
                goto ProcExit;
                }
            Sleep(1);
            continue;
            }

        if (_lwrite(hFile, Buff, RecvBytes)!=RecvBytes)
            {
            printf("Disk Full\n");
            goto ProcExit;
            }

        TotalRecvBytes+=RecvBytes;
        if (GetTickCount()-Time>=3000)
            {
            printf("TotalRecvBytes=%u\n", TotalRecvBytes);
            Time=GetTickCount();
            }
        }

    ProcExit:
    if (hFile!=HFILE_ERROR) _lclose(hFile);
    if (hSocket!=INVALID_SOCKET) closesocket(hSocket);
    WSACleanup();
    return 0;
    }

