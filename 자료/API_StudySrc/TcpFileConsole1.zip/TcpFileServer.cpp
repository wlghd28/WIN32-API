///////////////////////////////////////////////////////////////////////////////
//              HTTP ���� �ܼ� ���α׷� ����
//
//          http://127.0.0.1/FileManager?Cmd=FileList&Path=C:/Users
//
// ������:
// ���α׷���:
///////////////////////////////////////////////////////////////////////////////

#pragma warning(disable:4996)   //���ȿ� ����ϴٴ� �ܼҸ��� ����
#define  WIN32_LEAN_AND_MEAN
#undef UNICODE
#include <windows.h>
#include <winsock2.h>
#include <stdio.h>

#define LOCAL(Type) static Type WINAPI


#define SERVERPORT      80
#define HTTPROOT        "C:/HttpRoot"

#define HTTP_BADREQUST          400


//-----------------------------------------------------------------------------
//      ���� ���� �ݴϴ�
//-----------------------------------------------------------------------------
int WINAPI GetMin(int A, int B) {return A<=B ? A:B;}



//-----------------------------------------------------------------------------
//      ������ �ʱ�ȭ
//-----------------------------------------------------------------------------
BOOL WINAPI SocketInit(WSADATA *lpWSAD)
    {
    BOOL Rslt=FALSE;
    WSADATA WSAD;

    if (lpWSAD==NULL) lpWSAD=&WSAD;
    if (WSAStartup(MAKEWORD(2, 2), lpWSAD)!=0) goto DispErr;
    if (lpWSAD->wVersion!=0x0202)       //WS_32.DLL �����˻�
        {
        WSACleanup();

        DispErr:
        printf("���϶��̺귯���� �ʱ�ȭ �� �� �����ϴ�.");
        goto ProcExit;
        }
    Rslt++;

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      Port�� ������ (IP�� ���ε��, ��Ʈ�� ��Ʋ�ε��)
//-----------------------------------------------------------------------------
int WINAPI MyBind(SOCKET hSocket, LPCSTR IP, WORD PortNo)
    {
    SOCKADDR_IN SA;

    ZeroMemory(&SA, sizeof(SOCKADDR_IN));
    SA.sin_family=AF_INET;
    SA.sin_port=htons(PortNo);
    SA.sin_addr.s_addr=inet_addr(IP);
    return bind(hSocket, (SOCKADDR*)&SA, sizeof(SA));
    }



//-----------------------------------------------------------------------------
//      IP�� ���ڿ��� ����� �� (inet_ntoa()�� ���� ���)
//      IPAddr�� �򿣵����
//-----------------------------------------------------------------------------
LPSTR WINAPI IPtoA(LPSTR Buff, DWORD IPAddr)
    {
    wsprintf(Buff, "%d.%d.%d.%d", IPAddr&0xFF, (IPAddr>>8)&0xFF, (IPAddr>>16)&0xFF, (IPAddr>>24)&0xFF); // SA.sin_addr.s_net, SA.sin_addr.s_host, SA.sin_addr.s_lh, SA.sin_addr.s_impno
    return Buff;
    }



//-----------------------------------------------------------------------------
//      Accept()�� �����ϴ� �Լ�
//-----------------------------------------------------------------------------
int WINAPI MyAccept(SOCKET hSockSvr, LPSTR ConnectedIP)
    {
    int Len;
    SOCKET hSockConn;
    SOCKADDR_IN SAI;

    Len=sizeof(SOCKADDR_IN);
    hSockConn=accept(hSockSvr, (SOCKADDR*)&SAI, &Len);
    if (ConnectedIP) IPtoA(ConnectedIP, SAI.sin_addr.s_addr);
    return hSockConn;
    }



//-----------------------------------------------------------------------------
//          �־��� Byte�� ��� �����մϴ�
//-----------------------------------------------------------------------------
LOCAL(BOOL) SendAll(SOCKET hSocket, LPCSTR Data, int DataSize)
    {
    int  Sended, Err;
    BOOL Rslt=FALSE;

    while (DataSize>0)
        {
        if ((Sended=send(hSocket, Data, DataSize, 0))<=0)
            {
            if ((Err=WSAGetLastError())==WSAEWOULDBLOCK)
                {
                Sleep(1);
                continue;
                }
            printf("send() error=%d\n", Err);
            goto ProcExit;
            }
        DataSize-=Sended;
        Data+=Sended;
        }
    Rslt=TRUE;

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      ���ڿ��� �����մϴ�
//-----------------------------------------------------------------------------
int WINAPI SendStr(SOCKET hSocket, LPCSTR Data)
    {
    return SendAll(hSocket, Data, lstrlen(Data));
    }



//-----------------------------------------------------------------------------
//      ������ ������ŷ���� ��ȯ�մϴ�
//-----------------------------------------------------------------------------
int WINAPI SetNonBlockingMode(SOCKET hSocket, BOOL NonBlockingFg)
    {
    return ioctlsocket(hSocket, FIONBIO, (DWORD*)&NonBlockingFg);
    }



//-----------------------------------------------------------------------------
//      ������ �д´�
//-----------------------------------------------------------------------------
BOOL WINAPI RecvLine(SOCKET hSocket, LPSTR Buff, int BuffSize, DWORD Timeout)
    {
    BOOL Rslt=FALSE;
    CHAR Cha;
    DWORD Time;

    Time=GetTickCount();
    for (;;)
        {
        if (recv(hSocket, &Cha, 1, 0)<=0)
            {
            if (WSAGetLastError()!=WSAEWOULDBLOCK) break;
            if (GetTickCount()-Time>=Timeout) break;
            Sleep(1);
            continue;
            }
        if (Cha=='\r') continue;
        if (Cha=='\n') {Rslt=TRUE; break;}
        if (BuffSize>1) {*Buff++=Cha; BuffSize--;}
        }

    if (BuffSize>0) *Buff=0;
    return Rslt;
    }



//-----------------------------------------------------------------------------
//              ������ ��ŵ�մϴ�
//-----------------------------------------------------------------------------
LPCSTR WINAPI SkipSpace(LPCSTR Str)
    {
    BYTE Cha;

    for (;;)
        {
        Cha=*Str++;
        if (Cha==0 || Cha>' ') break;
        }
    return Str-1;
    }



//-----------------------------------------------------------------------------
//      ���� ��ġ �ܾ ���� �ݴϴ� (�����̳� TAB����) (sscanf()�� %s���)
//      ���� �ܾ��� ������ġ�� ������
//      '�� "�� ���ΰ�� �� ���̸� ��� ���� �ݴϴ�
//-----------------------------------------------------------------------------
LPCSTR WINAPI ScanWord(LPCSTR Str, LPSTR Buff, int BuffLen)
    {
    int Cha, FirstCha, Dest=0;

    Str=SkipSpace(Str);
    FirstCha=Str[0];
    if (FirstCha==0x27 || FirstCha==0x22) Str++;     //"'", '"'
    else FirstCha=0;

    for (;;)
        {
        Cha=*(BYTE*)Str++;
        if (Cha==0) {Str--; break;}
        if (FirstCha!=0)
            {
            if (FirstCha==Cha) break;
            }
        else{
            if (Cha<=' ') break;
            }
        if (Dest+1<BuffLen) Buff[Dest++]=Cha;
        }

    if (Dest<BuffLen) Buff[Dest]=0;
    return SkipSpace(Str);
    }



//------------------------------------------------------------------------------
//      ���ڿ��� �и��մϴ� (�и����� ������ ���ڿ��� ��)
//------------------------------------------------------------------------------
LPSTR WINAPI SeparatStr(LPSTR Str, CHAR SepCha)
    {
    LPSTR lp;

    if ((lp=strchr(Str, SepCha))!=NULL)
        {
        lp[0]=0;
        lp++;
        }
    return lp;
    }




//------------------------------------------------------------------------------
//      �����ڸ� ������ ���ڿ��� �ٲ�
//      Sub%C1%A6%B8%F122%3D%2611 -> Sub����22=&11
//------------------------------------------------------------------------------
VOID WINAPI DecodeUrl(LPSTR Url)
    {
    BYTE B1, B2;
    LPSTR Dest;

    Dest=Url;
    for (;;)
        {
        if ((B1=*Url++)==0) break;
        if (B1=='+') B1=' ';
        else if (B1=='%')
            {
            if ((B2=*Url++)==0) break;
            B2-='0'; if (B2>9) B2-=7;

            if ((B1=*Url++)==0) break;
            B1-='0'; if (B1>9) B1-=7;

            B1|=B2<<4;
            }
        *Dest++=B1;
        }
    *Dest=0;
    }



//-----------------------------------------------------------------------------
//      VAR1=DATA1&VAR2=DATA2&name=�ҿ�����&age=35
//-----------------------------------------------------------------------------
BOOL WINAPI GetUrlVarText(LPCSTR WebArgList, LPCSTR VarName, LPSTR DataBuff, int BuffSize)
    {
    int Rslt=FALSE, Len;
    LPCSTR NextPos, VarData;

    DataBuff[0]=0;
    Len=lstrlen(VarName);
    while (WebArgList[0]!=0)
        {
        if (lstrlen(WebArgList)<=Len) break;
        NextPos=strchr(WebArgList, '&');
        if (WebArgList[Len]=='=' && memcmp(WebArgList, VarName, Len)==0)
            {
            VarData=WebArgList+Len+1;
            if (NextPos!=NULL) BuffSize=GetMin(BuffSize, NextPos-VarData+1);
            lstrcpyn(DataBuff, VarData, BuffSize);
            //StripQuoteSign(DataBuff);
            DecodeUrl(DataBuff);
            Rslt++;
            break;
            }
        if (NextPos==NULL) break;
        WebArgList=NextPos+1;
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      ���ϸ���� �� ũ���̾�Ʈ���� �����մϴ�
//-----------------------------------------------------------------------------
VOID WINAPI FileListProc(SOCKET hSocket, LPCSTR Path)
    {
    HANDLE hWFD;
    WIN32_FIND_DATAA WFD;
    CHAR Buff[MAX_PATH*2];

    SendStr(hSocket, "HTTP/1.0 200 OK\r\n"
                     "Server: FileDownloadProgram/1.00\r\n"
                     "\r\n");

    lstrcpy(Buff, Path);
    lstrcat(Buff, "/*.*");
    if ((hWFD=FindFirstFileA(Buff, &WFD))!=INVALID_HANDLE_VALUE)
        {
        do  {
            wsprintf(Buff, "\"%s\" %u\r\n", WFD.cFileName, WFD.nFileSizeLow);
            SendStr(hSocket, Buff);
            } while (FindNextFileA(hWFD, &WFD)!=FALSE);
        FindClose(hWFD);
        }
    }



//-----------------------------------------------------------------------------
//      �־��� ������ �����մϴ�
//-----------------------------------------------------------------------------
VOID WINAPI DeleteFileProc(SOCKET hSocket, LPCSTR Path)
    {
    SendStr(hSocket, "HTTP/1.0 200 OK\r\n"
                     "Server: FileDownloadProgram/1.00\r\n"
                     "\r\n");
    SendStr(hSocket, DeleteFile(Path) ? "�����Ǿ����ϴ�.\r\n":"������ �� �����ϴ�\r\n");
    }



//-----------------------------------------------------------------------------
//      Ŭ���̾�Ʈ�κ��� �����Ͽ� ���Ϸ� �����մϴ�
//-----------------------------------------------------------------------------
LOCAL(VOID) RecvFileProc(SOCKET hSocket, LPCSTR Path)
    {
    BOOL Rslt=FALSE;

    //Path �� ���� ����
    //recv �� �����ؼ� ���Ͽ� ����
    //������������� ������� Rslt=TRUE;

    if (Rslt)
        {
        SendStr(hSocket, "HTTP/1.0 200 OK\r\n"
                         "Server: FileDownloadProgram/1.00\r\n"
                         "\r\n"
                         "�� �޾ҽ��ϴ�\r\n");
        }
    else{
        SendStr(hSocket, "HTTP/1.0 401 Unauthorized\r\n"
                         "Server: FileDownloadProgram/1.00\r\n"
                         "\r\n"
                         "���� �� �����ϴ�\r\n");
        }
    }



//-----------------------------------------------------------------------------
//      Ŭ���̾�Ʈ�� ���� ���� ������ ó����
//      Param: 'Cmd=FileList&Path=C:/User'
//-----------------------------------------------------------------------------
#define SFM_NONE        0
#define SFM_DOWNLOAD    1
int WINAPI SvrFileManager(SOCKET hSocket, LPSTR Param, OUT LPSTR DownFName)
    {
    int  Rslt=SFM_NONE;
    CHAR Cmd[16], Path[MAX_PATH];

    GetUrlVarText(Param, "Cmd", Cmd, sizeof(Cmd));
    GetUrlVarText(Param, "Path", Path, sizeof(Path));

    if (lstrcmp(Cmd, "FileList")==0)
        {
        FileListProc(hSocket, Path);
        }
    else if (lstrcmp(Cmd, "DeleteFile")==0)
        {
        DeleteFileProc(hSocket, Path);
        }
    else if (lstrcmp(Cmd, "Download")==0)
        {
        lstrcpy(DownFName, Path);
        Rslt=SFM_DOWNLOAD;
        }
    else if (lstrcmp(Cmd, "Upload")==0)
        {
        RecvFileProc(hSocket, Path);
        }
    else{
        SendStr(hSocket, "HTTP/1.0 400 BadRequest\r\n"
                         "Server: MyHttpServer/1.00\r\n"
                         "\r\n"
                         "No Support...");
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      �����ڿ��� ������ �Ѱ��ִ� �Լ�
//-----------------------------------------------------------------------------
VOID WINAPI HttpFileUpload(SOCKET hSocket)
    {
    DWORD Dw;
    LPCSTR lp;
    HFILE hFile=HFILE_ERROR;
    LPSTR Param;
    CHAR  Buff[MAX_PATH+40], OneWord[MAX_PATH+40], FileName[MAX_PATH];

    //(1) Http����� ù�� ����
    if (RecvLine(hSocket, Buff, sizeof(Buff), 5000)==FALSE)
        {
        printf("Http No Header\n");
        goto ProcExit;
        }
    printf("%s\n", Buff);

    lp=ScanWord(Buff, OneWord, sizeof(OneWord));
    if (lstrcmp(OneWord, "GET")!=0)
        {
        printf("Unsupported Http Command\n");
        goto ProcExit;
        }
    lp=ScanWord(lp, FileName, sizeof(FileName));    //FileName='/FileManager?Cmd=FileList&Path=C:/User'
    DecodeUrl(FileName);        //%20-> ' '

    //(2) ������ ��� ����
    for (;;)
        {
        if (RecvLine(hSocket, Buff, sizeof(Buff), 5000)==FALSE)
            {
            printf("Http No Header\n");
            goto ProcExit;
            }
        printf("%s\n", Buff);
        if (Buff[0]==0) break;  //����� ���̸�
        }

    //������ Ŭ���̾�Ʈ�� ������ ó��
    Param=SeparatStr(FileName, '?');
    if (lstrcmp(FileName, "/FileManager")==0)
        {
        if (SvrFileManager(hSocket, Param, Buff)==SFM_DOWNLOAD) goto SendFile;
        goto ProcExit;
        }

    lstrcpy(Buff, HTTPROOT);
    lstrcat(Buff, FileName);

    SendFile:
    printf("UploadFile: '%s'\n", Buff);
    if ((Dw=GetFileAttributes(Buff))==(DWORD)-1 ||
        (Dw & FILE_ATTRIBUTE_DIRECTORY)!=0 ||
        (hFile=_lopen(Buff, OF_READ))==HFILE_ERROR)
        {
        SendStr(hSocket, "HTTP/1.0 404 NotFound\r\n"
                         "Server: MyHttpServer/1.00\r\n"
                         "\r\n");
        goto ProcExit;
        }

    //(3) ������� ����
    wsprintf(Buff, "HTTP/1.0 200 OK\r\n"
                   "Host: www.ojang.pe.kr\r\n"
                   "Server: FileDownloadProgram/1.00\r\n"
                   "Content-Length: %d\r\n"
                   "\r\n", GetFileSize((HANDLE)hFile, NULL));
    SendStr(hSocket, Buff);


    SetNonBlockingMode(hSocket, TRUE);

    for (;;)
        {
        int ReadBytes;

        if ((ReadBytes=_lread(hFile, Buff, sizeof(Buff)))==0) break;
        if (ReadBytes==HFILE_ERROR) break;
        SendAll(hSocket, Buff, ReadBytes);
        }

    ProcExit:
    closesocket(hSocket);
    if (hFile!=HFILE_ERROR) _lclose(hFile);
    }



//-----------------------------------------------------------------------------
//      �ܼ� ��Ǯ ����
//-----------------------------------------------------------------------------
int main()
    {
    SOCKET hSocket=INVALID_SOCKET;
    CHAR ConnectedIP[20];

    printf("Http ���� ���α׷�\n");

    SocketInit(NULL);

    if ((hSocket=socket(AF_INET, SOCK_STREAM, 0))==INVALID_SOCKET)
        {
        printf("socket() �Լ� ����: %d\n", WSAGetLastError());
        goto ProcExit;
        }

    if (MyBind(hSocket, "0.0.0.0", SERVERPORT)==SOCKET_ERROR)
        {
        printf("MyBind() Error %d\n", WSAGetLastError());
        goto ProcExit;
        }

    if (listen(hSocket, SOMAXCONN)==SOCKET_ERROR)   //Ŭ���̾�Ʈ�� ������ �޾Ƶ��̴� ���� Ȱ��ȭ ��Ŵ
        {
        printf("listen() Error %d\n", WSAGetLastError());
        goto ProcExit;
        }

    for (;;)
        {
        SOCKET hSocketClient;

        if ((hSocketClient=MyAccept(hSocket, ConnectedIP))==INVALID_SOCKET)
            {
            printf("MyAccept error\n");
            continue;
            }
        printf("������: %s\n", ConnectedIP);

        HttpFileUpload(hSocketClient);
        }

    ProcExit:
    if (hSocket!=INVALID_SOCKET) closesocket(hSocket);
    WSACleanup();
    return 0;
    }

