///////////////////////////////////////////////////////////////////////////////
//              HTTP ���� �ܼ� ���α׷� ����
//
// ������:
// ���α׷���:
///////////////////////////////////////////////////////////////////////////////

#pragma warning(disable:4996)   //���ȿ� ����ϴٴ� �ܼҸ��� ����
#define  WIN32_LEAN_AND_MEAN
#undef UNICODE
#include <windows.h>
#include <winsock2.h>
#include <stdio.h>


#define SERVERPORT      80
#define HTTPROOT        "C:/HttpRoot"


//-----------------------------------------------------------------------------
//      ������ �ʱ�ȭ
//-----------------------------------------------------------------------------
BOOL WINAPI SocketInit(WSADATA *lpWSAD)
    {
    BOOL Rslt=FALSE;
    WSADATA WSAD;

    if (lpWSAD==NULL) lpWSAD=&WSAD;
    if (WSAStartup(MAKEWORD(2, 2), lpWSAD)!=0) goto DispErr;
    if (lpWSAD->wVersion!=0x0202)       //WS_32.DLL �����˻�
        {
        WSACleanup();

        DispErr:
        printf("���϶��̺귯���� �ʱ�ȭ �� �� �����ϴ�.");
        goto ProcExit;
        }
    Rslt++;

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      Port�� ������ (IP�� ���ε��, ��Ʈ�� ��Ʋ�ε��)
//-----------------------------------------------------------------------------
int WINAPI MyBind(SOCKET hSocket, LPCSTR IP, WORD PortNo)
    {
    SOCKADDR_IN SA;

    ZeroMemory(&SA, sizeof(SOCKADDR_IN));
    SA.sin_family=AF_INET;
    SA.sin_port=htons(PortNo);
    SA.sin_addr.s_addr=inet_addr(IP);
    return bind(hSocket, (SOCKADDR*)&SA, sizeof(SA));
    }



//-----------------------------------------------------------------------------
//      IP�� ���ڿ��� ����� �� (inet_ntoa()�� ���� ���)
//      IPAddr�� �򿣵����
//-----------------------------------------------------------------------------
LPSTR WINAPI IPtoA(LPSTR Buff, DWORD IPAddr)
    {
    wsprintf(Buff, "%d.%d.%d.%d", IPAddr&0xFF, (IPAddr>>8)&0xFF, (IPAddr>>16)&0xFF, (IPAddr>>24)&0xFF); // SA.sin_addr.s_net, SA.sin_addr.s_host, SA.sin_addr.s_lh, SA.sin_addr.s_impno
    return Buff;
    }



//-----------------------------------------------------------------------------
//      Accept()�� �����ϴ� �Լ�
//-----------------------------------------------------------------------------
int WINAPI MyAccept(SOCKET hSockSvr, LPSTR ConnectedIP)
    {
    int Len;
    SOCKET hSockConn;
    SOCKADDR_IN SAI;

    Len=sizeof(SOCKADDR_IN);
    hSockConn=accept(hSockSvr, (SOCKADDR*)&SAI, &Len);
    if (ConnectedIP) IPtoA(ConnectedIP, SAI.sin_addr.s_addr);
    return hSockConn;
    }



//-----------------------------------------------------------------------------
//      ���ڿ��� �����մϴ�
//-----------------------------------------------------------------------------
int WINAPI SendStr(SOCKET hSocket, LPCSTR Data)
    {
    return send(hSocket, Data, lstrlen(Data), 0);
    }



//-----------------------------------------------------------------------------
//      ������ ������ŷ���� ��ȯ�մϴ�
//-----------------------------------------------------------------------------
int WINAPI SetNonBlockingMode(SOCKET hSocket, BOOL NonBlockingFg)
    {
    return ioctlsocket(hSocket, FIONBIO, (DWORD*)&NonBlockingFg);
    }



//-----------------------------------------------------------------------------
//      ������ �д´�
//-----------------------------------------------------------------------------
BOOL WINAPI RecvLine(SOCKET hSocket, LPSTR Buff, int BuffSize, DWORD Timeout)
    {
    BOOL Rslt=FALSE;
    CHAR Cha;
    DWORD Time;

    Time=GetTickCount();
    for (;;)
        {
        if (recv(hSocket, &Cha, 1, 0)<=0)
            {
            if (WSAGetLastError()!=WSAEWOULDBLOCK) break;
            if (GetTickCount()-Time>=Timeout) break;
            Sleep(1);
            continue;
            }
        if (Cha=='\r') continue;
        if (Cha=='\n') {Rslt=TRUE; break;}
        if (BuffSize>1) {*Buff++=Cha; BuffSize--;}
        }

    if (BuffSize>0) *Buff=0;
    return Rslt;
    }



//-----------------------------------------------------------------------------
//              ������ ��ŵ�մϴ�
//-----------------------------------------------------------------------------
LPCSTR WINAPI SkipSpace(LPCSTR Str)
    {
    BYTE Cha;

    for (;;)
        {
        Cha=*Str++;
        if (Cha==0 || Cha>' ') break;
        }
    return Str-1;
    }



//-----------------------------------------------------------------------------
//      ���� ��ġ �ܾ ���� �ݴϴ� (�����̳� TAB����) (sscanf()�� %s���)
//      ���� �ܾ��� ������ġ�� ������
//      '�� "�� ���ΰ�� �� ���̸� ��� ���� �ݴϴ�
//-----------------------------------------------------------------------------
LPCSTR WINAPI ScanWord(LPCSTR Str, LPSTR Buff, int BuffLen)
    {
    int Cha, FirstCha, Dest=0;

    Str=SkipSpace(Str);
    FirstCha=Str[0];
    if (FirstCha==0x27 || FirstCha==0x22) Str++;     //"'", '"'
    else FirstCha=0;

    for (;;)
        {
        Cha=*(BYTE*)Str++;
        if (Cha==0) {Str--; break;}
        if (FirstCha!=0)
            {
            if (FirstCha==Cha) break;
            }
        else{
            if (Cha<=' ') break;
            }
        if (Dest+1<BuffLen) Buff[Dest++]=Cha;
        }

    if (Dest<BuffLen) Buff[Dest]=0;
    return SkipSpace(Str);
    }



//-----------------------------------------------------------------------------
//      �����ڿ��� ������ �Ѱ��ִ� �Լ�
//-----------------------------------------------------------------------------
VOID WINAPI HttpFileUpload(SOCKET hSocket)
    {
    DWORD Dw;
    LPCSTR lp;
    HFILE hFile=HFILE_ERROR;
    CHAR  Buff[256], OneWord[256], FileName[256];

    //(1) Http����� ù�� ����
    if (RecvLine(hSocket, Buff, sizeof(Buff), 5000)==FALSE)
        {
        printf("Http No Header\n");
        goto ProcExit;
        }

    lp=ScanWord(Buff, OneWord, sizeof(OneWord));
    if (lstrcmp(OneWord, "GET")!=0)
        {
        printf("Unsupported Http Command\n");
        goto ProcExit;
        }
    lp=ScanWord(lp, FileName, sizeof(FileName));

    //(2) ������ ��� ����
    for (;;)
        {
        if (RecvLine(hSocket, Buff, sizeof(Buff), 5000)==FALSE)
            {
            printf("Http No Header\n");
            goto ProcExit;
            }
        if (Buff[0]==0) break;  //����� ���̸�
        }

    lstrcpy(Buff, HTTPROOT);
    lstrcat(Buff, FileName);
    if ((Dw=GetFileAttributes(Buff))==(DWORD)-1 ||
        (Dw & FILE_ATTRIBUTE_DIRECTORY)!=0 ||
        (hFile=_lopen(Buff, OF_READ))==HFILE_ERROR)
        {
        SendStr(hSocket, "HTTP/1.0 404 NotFound\r\n"
                         "Server: MyHttpServer/1.00\r\n"
                         "\r\n");
        goto ProcExit;
        }

    //(3) ������� ����
    wsprintf(Buff, "HTTP/1.0 200 OK\r\n"
                   "Host: www.ojang.pe.kr\r\n"
                   "User-Agent: FileDownloadProgram/1.00\r\n"
                   "Content-Length: %d\r\n"
                   "\r\n", GetFileSize((HANDLE)hFile, NULL));
    SendStr(hSocket, Buff);


    SetNonBlockingMode(hSocket, TRUE);

    for (;;)
        {
        int ReadBytes, Sended;

        if ((ReadBytes=_lread(hFile, Buff, sizeof(Buff)))==0) break;
        if (ReadBytes==HFILE_ERROR) break;

        lp=Buff;
        while (ReadBytes>0)
            {
            if ((Sended=send(hSocket, lp, ReadBytes, 0))<=0)
                {
                int Err;

                if ((Err=WSAGetLastError())==WSAEWOULDBLOCK)
                    {
                    Sleep(1);
                    continue;
                    }
                printf("send() error=%d\n", Err);
                break;
                }
            ReadBytes-=Sended;
            lp+=Sended;
            }
        }

    ProcExit:
    closesocket(hSocket);
    if (hFile!=HFILE_ERROR) _lclose(hFile);
    }



//-----------------------------------------------------------------------------
//      �ܼ� ��Ǯ ����
//-----------------------------------------------------------------------------
int main()
    {
    SOCKET hSocket=INVALID_SOCKET;
    CHAR ConnectedIP[20];

    printf("Http ���� ���α׷�\n");

    SocketInit(NULL);

    if ((hSocket=socket(AF_INET, SOCK_STREAM, 0))==INVALID_SOCKET)
        {
        printf("socket() �Լ� ����: %d\n", WSAGetLastError());
        goto ProcExit;
        }

    if (MyBind(hSocket, "0.0.0.0", SERVERPORT)==SOCKET_ERROR)
        {
        printf("MyBind() Error %d\n", WSAGetLastError());
        goto ProcExit;
        }

    if (listen(hSocket, SOMAXCONN)==SOCKET_ERROR)   //Ŭ���̾�Ʈ�� ������ �޾Ƶ��̴� ���� Ȱ��ȭ ��Ŵ
        {
        printf("listen() Error %d\n", WSAGetLastError());
        goto ProcExit;
        }

    for (;;)
        {
        SOCKET hSocketClient;

        if ((hSocketClient=MyAccept(hSocket, ConnectedIP))==INVALID_SOCKET)
            {
            printf("MyAccept error\n");
            continue;
            }
        printf("������: %s\n", ConnectedIP);

        HttpFileUpload(hSocketClient);
        }

    ProcExit:
    if (hSocket!=INVALID_SOCKET) closesocket(hSocket);
    WSACleanup();
    return 0;
    }

