///////////////////////////////////////////////////////////////////////////////
//              HTTP ���� �ܼ� ���α׷� ����
//
//          http://127.0.0.1/FileManager?Cmd=FileList&Path=C:/Users
//
// ������:
// ���α׷���:
///////////////////////////////////////////////////////////////////////////////

#pragma warning(disable:4996)   //���ȿ� ����ϴٴ� �ܼҸ��� ����
#define  WIN32_LEAN_AND_MEAN
#undef UNICODE
#include <windows.h>
#include <winsock2.h>
#include <stdio.h>
#include "SLIB.H"



#define SERVERPORT      80
#define HTTPROOT        "C:/HttpRoot"




//-----------------------------------------------------------------------------
//      ���ϸ���� �� ũ���̾�Ʈ���� �����մϴ�
//-----------------------------------------------------------------------------
VOID WINAPI FileListProc(SOCKET hSocket, LPCSTR Path)
    {
    HANDLE hWFD;
    WIN32_FIND_DATAA WFD;
    CHAR Buff[MAX_PATH*2];

    SendStr(hSocket, "HTTP/1.0 200 OK\r\n"
                     "Server: FileDownloadProgram/1.00\r\n"
                     "\r\n");

    lstrcpy(Buff, Path);
    lstrcat(Buff, "/*.*");
    if ((hWFD=FindFirstFileA(Buff, &WFD))!=INVALID_HANDLE_VALUE)
        {
        do  {
            wsprintf(Buff, "\"%s\" %u\r\n", WFD.cFileName, WFD.nFileSizeLow);
            SendStr(hSocket, Buff);
            } while (FindNextFileA(hWFD, &WFD)!=FALSE);
        FindClose(hWFD);
        }
    }



//-----------------------------------------------------------------------------
//      �־��� ������ �����մϴ�
//-----------------------------------------------------------------------------
VOID WINAPI DeleteFileProc(SOCKET hSocket, LPCSTR Path)
    {
    SendStr(hSocket, "HTTP/1.0 200 OK\r\n"
                     "Server: FileDownloadProgram/1.00\r\n"
                     "\r\n");
    SendStr(hSocket, DeleteFile(Path) ? "�����Ǿ����ϴ�.\r\n":"������ �� �����ϴ�\r\n");
    }



//-----------------------------------------------------------------------------
//      Ŭ���̾�Ʈ�κ��� �����Ͽ� ���Ϸ� �����մϴ�
//-----------------------------------------------------------------------------
LOCAL(VOID) RecvFileProc(SOCKET hSocket, LPCSTR Path, DWORD FileSize)
    {
    if (RecvToFile(hSocket, Path, FileSize)!=FALSE)
        {
        SendStr(hSocket, "HTTP/1.0 200 OK\r\n"
                         "Server: FileDownloadProgram/1.00\r\n"
                         "\r\n"
                         "�� �޾ҽ��ϴ�\r\n");
        }
    else{
        SendStr(hSocket, "HTTP/1.0 401 Unauthorized\r\n"
                         "Server: FileDownloadProgram/1.00\r\n"
                         "\r\n"
                         "���� �� �����ϴ�\r\n");
        }
    }



//-----------------------------------------------------------------------------
//      Ŭ���̾�Ʈ�� ���� ���� ������ ó����
//      Param: 'Cmd=FileList&Path=C:/User'
//-----------------------------------------------------------------------------
#define SFM_NONE        0
#define SFM_DOWNLOAD    1
int WINAPI SvrFileManager(SOCKET hSocket, LPSTR Param, OUT LPSTR DownFName, DWORD FileSize)
    {
    int  Rslt=SFM_NONE;
    CHAR Cmd[16], Path[MAX_PATH];

    GetUrlVarText(Param, "Cmd", Cmd, sizeof(Cmd));
    GetUrlVarText(Param, "Path", Path, sizeof(Path));

    if (lstrcmp(Cmd, "FileList")==0)
        {
        FileListProc(hSocket, Path);
        }
    else if (lstrcmp(Cmd, "DeleteFile")==0)
        {
        DeleteFileProc(hSocket, Path);
        }
    else if (lstrcmp(Cmd, "Download")==0)
        {
        lstrcpy(DownFName, Path);
        Rslt=SFM_DOWNLOAD;
        }
    else if (lstrcmp(Cmd, "Upload")==0)
        {
        RecvFileProc(hSocket, Path, FileSize);
        }
    else{
        SendStr(hSocket, "HTTP/1.0 400 BadRequest\r\n"
                         "Server: MyHttpServer/1.00\r\n"
                         "\r\n"
                         "No Support...");
        }
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      �����ڿ��� ������ �Ѱ��ִ� �Լ�
//-----------------------------------------------------------------------------
VOID WINAPI HttpFileUpload(SOCKET hSocket)
    {
    DWORD Dw, FileSize=0;
    LPCSTR lp;
    HFILE hFile=HFILE_ERROR;
    LPSTR Param;
    CHAR  Buff[MAX_PATH+40], OneWord[MAX_PATH+40], FileName[MAX_PATH], LocalPath[MAX_PATH];

    //(1) Http����� ù�� ����
    if (RecvLine(hSocket, Buff, sizeof(Buff), 5000)==FALSE)
        {
        printf("Http No Header\n");
        goto ProcExit;
        }
    printf("%s\n", Buff);

    lp=ScanWord(Buff, OneWord, sizeof(OneWord));
    if (lstrcmp(OneWord, "GET")!=0)
        {
        printf("Unsupported Http Command\n");
        goto ProcExit;
        }
    lp=ScanWord(lp, FileName, sizeof(FileName));    //FileName='/FileManager?Cmd=FileList&Path=C:/User'
    DecodeUrl(FileName);        //%20-> ' '

    //(2) ������ ��� ����
    for (;;)
        {
        if (RecvLine(hSocket, Buff, sizeof(Buff), 5000)==FALSE)
            {
            printf("Http No Header\n");
            goto ProcExit;
            }
        printf("%s\n", Buff);
        if (Buff[0]==0) break;  //����� ���̸�

        if (CompMemStr(Buff, "Content-Length:")==0) FileSize=AtoI(NextWord(Buff));
        }

    //������ Ŭ���̾�Ʈ�� ������ ó��
    Param=SeparatStr(FileName, '?');
    if (lstrcmp(FileName, "/FileManager")==0)
        {
        if (SvrFileManager(hSocket, Param, LocalPath, FileSize)==SFM_DOWNLOAD) goto SendFile;
        goto ProcExit;
        }

    lstrcpy(LocalPath, HTTPROOT);
    lstrcat(LocalPath, FileName);

    SendFile:
    printf("UploadFile: '%s'\n", LocalPath);
    if ((Dw=GetFileAttributes(LocalPath))==(DWORD)-1 ||
        (Dw & FILE_ATTRIBUTE_DIRECTORY)!=0)
        {
        SendStr(hSocket, "HTTP/1.0 404 NotFound\r\n"
                         "Server: MyHttpServer/1.00\r\n"
                         "\r\n");
        goto ProcExit;
        }

    //(3) ������� ����
    wsprintf(Buff, "HTTP/1.0 200 OK\r\n"
                   "Host: www.ojang.pe.kr\r\n"
                   "Server: FileDownloadProgram/1.00\r\n"
                   "Content-Length: %lld\r\n"
                   "\r\n", GetFileSize(LocalPath));
    SendStr(hSocket, Buff);

    SetNonBlockingMode(hSocket, TRUE);
    SendFile(hSocket, LocalPath);

    ProcExit:
    closesocket(hSocket);
    if (hFile!=HFILE_ERROR) _lclose(hFile);
    }



//-----------------------------------------------------------------------------
//      �ܼ� ��Ǯ ����
//-----------------------------------------------------------------------------
int main()
    {
    SOCKET hSocket=INVALID_SOCKET;
    CHAR ConnectedIP[20];

    printf("Http ���� ���α׷�\n");

    SocketInit(NULL);

    if ((hSocket=socket(AF_INET, SOCK_STREAM, 0))==INVALID_SOCKET)
        {
        printf("socket() �Լ� ����: %d\n", WSAGetLastError());
        goto ProcExit;
        }

    if (MyBind(hSocket, "0.0.0.0", SERVERPORT)==SOCKET_ERROR)
        {
        printf("MyBind() Error %d\n", WSAGetLastError());
        goto ProcExit;
        }

    if (listen(hSocket, SOMAXCONN)==SOCKET_ERROR)   //Ŭ���̾�Ʈ�� ������ �޾Ƶ��̴� ���� Ȱ��ȭ ��Ŵ
        {
        printf("listen() Error %d\n", WSAGetLastError());
        goto ProcExit;
        }

    for (;;)
        {
        SOCKET hSocketClient;

        if ((hSocketClient=MyAccept(hSocket, ConnectedIP))==INVALID_SOCKET)
            {
            printf("MyAccept error\n");
            continue;
            }
        printf("������: %s\n", ConnectedIP);

        HttpFileUpload(hSocketClient);
        }

    ProcExit:
    if (hSocket!=INVALID_SOCKET) closesocket(hSocket);
    WSACleanup();
    return 0;
    }

