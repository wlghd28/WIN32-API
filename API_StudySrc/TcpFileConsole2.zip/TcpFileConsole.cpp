///////////////////////////////////////////////////////////////////////////////
//              TCP Ŭ���̾�Ʈ ���α׷�
//
//              ���� ���� �ܼ�
//
// ������:
// ���α׷���:
///////////////////////////////////////////////////////////////////////////////

#pragma warning(disable:4996)   //���ȿ� ����ϴٴ� �ܼҸ��� ����
#define  WIN32_LEAN_AND_MEAN
#undef   UNICODE
#include <windows.h>
#include <winsock2.h>
#include <ShlWApi.h>
#include <stdio.h>
#include "SLIB.H"



#define SERVERIP            "127.0.0.1"
#define SERVERPORT          80
#define DEFAULTHTTPPORTNO   80




//-----------------------------------------------------------------------------
//      Http Client
//      RecvBuffSize==0 �� ��쿡�� RecvBuff �� ���ϸ����� �ؼ� ���Ͽ� ������
//
//      ServerDomain�� �� http://Server:1234/File.html?User=MY
//
//��û���
//      GET /FileManager?Cmd=FileList&Path=C:/User HTTP/1.0
//      Host: www.ojang.pe.kr
//      User-Agent: FileDownloadProgram/1.00
//      Accept: */*
//
//�������
//      HTTP/1.1 200 OK
//      Date: Tue, 10 Jul 2018 14:32:02 GMT
//      Server: Apache/1.3.34 (Win32) PHP/4.4.2
//      Last-Modified: Wed, 05 Jul 2017 14:30:12 GMT    //������������ð�
//      Accept-Ranges: bytes
//      Content-Length: 59660947                        //����ũ��
//      Connection: close
//      Content-Type: application/zip
//      <����> ... ��� ��
//      ���ϸ�ü
//-----------------------------------------------------------------------------
LOCAL(int) HttpClient(LPCSTR Url, LPSTR RecvBuff, int RecvBuffSize)
    {
    int   Port=DEFAULTHTTPPORTNO, TotalRecvBytes=0, HttpRslt=0;
    SOCKET hSocket=INVALID_SOCKET;
    LPCSTR lp, SvrPath;
    CHAR Buff[MAX_PATH*3], Temp[40], Domain[64];

    SvrPath=SeparateUrl(Url, Domain, sizeof(Domain), &Port);
    if ((hSocket=socket(AF_INET, SOCK_STREAM, 0))==INVALID_SOCKET)
        {
        printf("socket(): %d\n", WSAGetLastError());
        goto ProcExit;
        }

    if (MyConnect(hSocket, Domain, Port)==SOCKET_ERROR)
        {
        printf("Connet Connect %s:%d\n", Domain, Port);
        goto ProcExit;
        }

    //��û ��� �۽�
    wsprintf(Buff, "GET %s HTTP/1.0\r\n"
                   "User-Agent: NULL\r\n"
                   "Accept: */*\r\n"
                   "\r\n", SvrPath ? SvrPath:"/");
    SendStr(hSocket, Buff);

    SetNonBlockingMode(hSocket, TRUE);

    //Http ���� ��� ����
    if (RecvLine(hSocket, Buff, sizeof(Buff), 5000)==FALSE) goto ProcExit;
    lp=ScanWord(Buff, Temp, sizeof(Temp));
    if (CompMemStr(Temp, "HTTP/")!=0)
        {
        printf("No http server\n");
        goto ProcExit;
        }
    if ((HttpRslt=AtoI(lp))!=200)
        {
        printf("http Result=%d\n", HttpRslt);
        goto ProcExit;
        }

    for (;;)
        {
        if (RecvLine(hSocket, Buff, sizeof(Buff), 5000)==FALSE) goto ProcExit;
        if (Buff[0]==0) break;  //��� ��
        }

    //���⼭���ʹ� ��ü�� ����
    if (RecvBuffSize>0)
        {
        TotalRecvBytes=RecvToMem(hSocket, RecvBuff, RecvBuffSize, 0);   //�޸𸮿� �ٿ�ε�
        }
    else{
        RecvToFile(hSocket, RecvBuff, 0);
        }

    ProcExit:
    if (hSocket!=INVALID_SOCKET) closesocket(hSocket);
    return TotalRecvBytes;
    }

LOCAL(int) HttpClient(LPCSTR Url, LPCSTR FileName)
    {
    return HttpClient(Url, (LPSTR)FileName, 0);
    }



//-----------------------------------------------------------------------------
//      ������ ���ε��ϴ� Http Ŭ���̾�Ʈ
//-----------------------------------------------------------------------------
LOCAL(int) HttpClientUpload(LPCSTR Url, LPSTR RecvBuff, int RecvBuffSize, LPCSTR ToUploadFName)
    {
    int   Port=DEFAULTHTTPPORTNO, RecvBytes, TotalRecvBytes=0, HttpRslt=0;
    SOCKET hSocket=INVALID_SOCKET;
    LPCSTR lp, SvrPath;
    CHAR Buff[MAX_PATH*3], Temp[40], Domain[64];

    SvrPath=SeparateUrl(Url, Domain, sizeof(Domain), &Port);
    if ((hSocket=socket(AF_INET, SOCK_STREAM, 0))==INVALID_SOCKET)
        {
        printf("socket(): %d\n", WSAGetLastError());
        goto ProcExit;
        }

    if (MyConnect(hSocket, Domain, Port)==SOCKET_ERROR)
        {
        printf("Connet Connect %s:%d\n", Domain, Port);
        goto ProcExit;
        }

    //��û ��� �۽�
    wsprintf(Buff, "GET %s HTTP/1.0\r\n"
                   "User-Agent: NULL\r\n"
                   "Content-Length: %I64d\r\n"
                   "Accept: */*\r\n"
                   "\r\n", SvrPath ? SvrPath:"/", GetFileSize(ToUploadFName));
    SendStr(hSocket, Buff);

    SetNonBlockingMode(hSocket, TRUE);

    //���� �ٵ� ����
    SendFile(hSocket, ToUploadFName);

    //Http ���� ��� ����
    if (RecvLine(hSocket, Buff, sizeof(Buff), 5000)==FALSE) goto ProcExit;
    lp=ScanWord(Buff, Temp, sizeof(Temp));
    if (CompMemStr(Temp, "HTTP/")!=0)
        {
        printf("No http server\n");
        goto ProcExit;
        }
    if ((HttpRslt=AtoI(lp))!=200)
        {
        printf("http Result=%d\n", HttpRslt);
        goto ProcExit;
        }

    for (;;)
        {
        if (RecvLine(hSocket, Buff, sizeof(Buff), 5000)==FALSE) goto ProcExit;
        if (Buff[0]==0) break;  //��� ��
        }

    //���⼭���ʹ� ��ü�� ����
    while (RecvBuffSize>0)
        {
        if ((RecvBytes=recv(hSocket, RecvBuff, RecvBuffSize, 0))<=0)
            {
            if (WSAGetLastError()!=WSAEWOULDBLOCK) break;
            Sleep(1);
            continue;
            }

        RecvBuff+=RecvBytes;
        RecvBuffSize-=RecvBytes;
        TotalRecvBytes+=RecvBytes;
        }

    ProcExit:
    if (hSocket!=INVALID_SOCKET) closesocket(hSocket);
    return TotalRecvBytes;
    }



//-----------------------------------------------------------------------------
//      �������� ���� ����� ������
//-----------------------------------------------------------------------------
LOCAL(VOID) DirProc(LPCSTR Param)
    {
    int RecvBytes;
    CHAR Url[MAX_PATH*2], RecvBuff[1024];

    if (Param==NULL)
        {
        printf("Dir �н�\n");
        goto ProcExit;
        }

    EncodeUrl(RecvBuff, Param, sizeof(RecvBuff));
    wsprintf(Url, "http://%s:%d/FileManager?Cmd=FileList&Path=%s", SERVERIP, SERVERPORT, RecvBuff);
    if ((RecvBytes=HttpClient(Url, RecvBuff, sizeof(RecvBuff)-1))==0)
        {
        printf("Dir Error\n");
        goto ProcExit;
        }
    RecvBuff[RecvBytes]=0;

    printf(RecvBuff);

    ProcExit:;
    }



//-----------------------------------------------------------------------------
//      �������� ������ ������
//-----------------------------------------------------------------------------
LOCAL(VOID) DelProc(LPCSTR Param)
    {
    int RecvBytes;
    CHAR Url[MAX_PATH*2], RecvBuff[1024];

    if (Param==NULL)
        {
        printf("Del ���������ϸ�\n");
        goto ProcExit;
        }

    EncodeUrl(RecvBuff, Param, sizeof(RecvBuff));
    wsprintf(Url, "http://%s:%d/FileManager?Cmd=DeleteFile&Path=%s", SERVERIP, SERVERPORT, RecvBuff);
    if ((RecvBytes=HttpClient(Url, RecvBuff, sizeof(RecvBuff)-1))==0)
        {
        printf("Dir Error\n");
        goto ProcExit;
        }
    RecvBuff[RecvBytes]=0;

    printf(RecvBuff);

    ProcExit:;
    }



//-----------------------------------------------------------------------------
//      �������� ������ �ٿ�ε���
//-----------------------------------------------------------------------------
LOCAL(VOID) DownlaodProc(LPCSTR Param)
    {
    int RecvBytes;
    CHAR Url[MAX_PATH*2], EncBuff[MAX_PATH*2];

    if (Param==NULL)
        {
        printf("Download �ٿ�������ϸ�\n");
        goto ProcExit;
        }

    EncodeUrl(EncBuff, Param, sizeof(EncBuff));
    wsprintf(Url, "http://%s:%d/FileManager?Cmd=Download&Path=%s", SERVERIP, SERVERPORT, EncBuff);
    //wsprintf(Url, "http://%s:%d/%s", SERVERIP, SERVERPORT, Param);
    if ((RecvBytes=HttpClient(Url, GetFileNameLoc(Param)))==0)
        {
        printf("Download Error\n");
        goto ProcExit;
        }
    printf("%d Bytes Download OK\n", RecvBytes);

    ProcExit:;
    }



//-----------------------------------------------------------------------------
//      ���� ���ε� �Լ�
//-----------------------------------------------------------------------------
LOCAL(BOOL) UploadFile(LPCSTR LocalPath, LPCSTR SvrPath)
    {
    int  RecvBytes;
    BOOL Rslt=FALSE;
    CHAR Url[MAX_PATH*2], EncSvrPath[MAX_PATH*2], RecvBuff[MAX_PATH];

    EncodeUrl(EncSvrPath, SvrPath, sizeof(EncSvrPath));
    wsprintf(Url, "http://%s:%d/FileManager?Cmd=Upload&Path=%s", SERVERIP, SERVERPORT, EncSvrPath);
    //wsprintf(Url, "http://%s:%d/%s", SERVERIP, SERVERPORT, Param);

    if ((RecvBytes=HttpClientUpload(Url, RecvBuff, sizeof(RecvBuff)-1, LocalPath))==0)
        {
        printf("Upload Error\n");
        goto ProcExit;
        }
    RecvBuff[RecvBytes]=0;
    printf("Upload '%s'\n", RecvBuff);
    Rslt=TRUE;

    ProcExit:
    return Rslt;
    }



//-----------------------------------------------------------------------------
//      �������� ������ �����Ŀ� ���ε���
//-----------------------------------------------------------------------------
LOCAL(VOID) UploadProc(LPCSTR Param)
    {
    LPCSTR lp;
    CHAR LocalPath[MAX_PATH], SvrPath[MAX_PATH];

    if (Param==NULL)
        {
        printf("Upload �������ϸ� �������ϸ�\n");
        goto ProcExit;
        }

    lp=ScanWord(Param, LocalPath, sizeof(LocalPath));
    ScanWord(lp, SvrPath, sizeof(SvrPath));

    UploadFile(LocalPath, SvrPath);

    ProcExit:;
    }



//-----------------------------------------------------------------------------
//      ���� ���ε�
//-----------------------------------------------------------------------------
LOCAL(VOID) UploadFolder(LPCSTR LocalPath, LPCSTR SvrPath)
    {
    HANDLE hWFD;
    WIN32_FIND_DATAA WFD;
    CHAR LocalFullPath[MAX_PATH], SvrFullPath[MAX_PATH*2], EncBuff[MAX_PATH*4];

    lstrcpy(SvrFullPath, SvrPath);
    CompletePath(SvrFullPath);

    lstrcpy(LocalFullPath, LocalPath);
    CompletePath(LocalFullPath);
    lstrcat(LocalFullPath, "*.*");

    if ((hWFD=FindFirstFileA(LocalFullPath, &WFD))!=INVALID_HANDLE_VALUE)
        {
        do  {
            lstrcpy((LPSTR)GetFileNameLoc(LocalFullPath), WFD.cFileName);
            lstrcpy((LPSTR)GetFileNameLoc(SvrFullPath), WFD.cFileName);

            if (WFD.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                {
                if (lstrcmp(WFD.cFileName, ".")!=0 &&
                    lstrcmp(WFD.cFileName, "..")!=0)
                    UploadFolder(LocalFullPath, SvrFullPath);
                }
            else{
                EncodeUrl(EncBuff, SvrFullPath, sizeof(EncBuff));
                Printf("UploadFile: %s\n", LocalFullPath);
                UploadFile(LocalFullPath, EncBuff);
                }
            } while (FindNextFileA(hWFD, &WFD)!=FALSE);
        FindClose(hWFD);
        }
    }



//-----------------------------------------------------------------------------
//      �������� ������ �����Ŀ� ���ε���
//-----------------------------------------------------------------------------
LOCAL(VOID) FolderUploadProc(LPCSTR Param)
    {
    LPCSTR lp;
    CHAR LocalPath[MAX_PATH], SvrPath[MAX_PATH];

    if (Param==NULL)
        {
        printf("Upload ���������� ����������\n");
        goto ProcExit;
        }

    lp=ScanWord(Param, LocalPath, sizeof(LocalPath));
    ScanWord(lp, SvrPath, sizeof(SvrPath));

    UploadFolder(LocalPath, SvrPath);

    ProcExit:;
    }



//-----------------------------------------------------------------------------
//      �ָܼ���
//-----------------------------------------------------------------------------
int main()
    {
    LPCSTR Param;
    CHAR Buff[512];

    printf("Remote Computer File Console Program Ver 1.00\n");

    SocketInit(NULL);

    for (;;)
        {
        gets_s(Buff, sizeof(Buff));
        Param=SeparatStr(Buff, ' ');

        if (lstrcmpi(Buff, "Quit")==0 ||
            lstrcmpi(Buff, "Exit")==0)
            {
            printf("Exit Program\n");
            break;
            }
        else if (lstrcmpi(Buff, "Dir")==0)      DirProc(Param);
        else if (lstrcmpi(Buff, "Del")==0)      DelProc(Param);
        else if (lstrcmpi(Buff, "Download")==0) DownlaodProc(Param);
        else if (lstrcmpi(Buff, "Upload")==0)   UploadProc(Param);
        else if (lstrcmpi(Buff, "FolderUpload")==0) FolderUploadProc(Param);
        else{
            printf("Not Support yet\n");
            }
        }

    WSACleanup();
    return 0;
    }

